const canvas2 = document.getElementById("snake-ai");
const ctx2 = canvas2.getContext("2d");
const highscore2 = document.getElementById("ai-score");
const button2 = document.getElementById("ai-start-button");

ctx2.fillRect(0,0,canvas2.width,canvas2.height);

//load model
const sess = new onnx.InferenceSession();
const loadingModelPromise = sess.loadModel("static/js/best_model.onnx");

let stop2 = false;

let head2 = new Point(head.x,head.y);

let body2 = [];
let tailLength2 = 2;

let apple2 = new Point(apple.x,apple.y);

let xVelocity2 = 0;
let yVelocity2 = 1;

let score2 = 0;
let record2 = 0;

let speed2 = 20;

var timer2;
function start2() {
  clearTimeout(timer2);
  if (button2.textContent == "Start") {
    stop2 = false;

    head2 = new Point(head.x,head.y);

    body2 = [];
    tailLength2 = 2;

    apple2 = new Point(apple.x,apple.y);

    xVelocity2 = 0;
    yVelocity2 = 1;

    score2 = 0;

    drawGame2();
    button2.textContent = "Stop";
  } else {
    stop2 = true;
    button2.textContent = "Start";
  }
}

function getState() {
  let point_l = new Point(head2.x - 1, head2.y);
  let point_r = new Point(head2.x + 1, head2.y);
  let point_u = new Point(head2.x, head2.y - 1);
  let point_d = new Point(head2.x, head2.y + 1);

  let dir_l = false, dir_r = false, dir_u = false, dir_d = false;
  switch(xVelocity2) {
    case 1: dir_r = true; break;
    case -1: dir_l = true; break;
    default:
    switch(yVelocity2) {
      case 1: dir_d = true; break;
      case -1: dir_u = true; break;
      default: break;
    }; break;
  }

  let tail_left_of_head = false, tail_right_of_head = false, tail_above_head = false, tail_below_head = false;
  for (var i = 0; i < body2.length; i++) {
          if (body2[i].y == head2.y) {
              if (body2[i].x < head2.x)
                  tail_left_of_head = true;
              else
                  tail_right_of_head = true;
          } else if (body2[i].x == head2.x) {
              if (body2[i].y < head2.y)
                  tail_above_head = true;
              else
                  tail_below_head = true;
          }
  }

  let trap_right = false, trap_left = false;
  for (var i = 0; i < body2.length; i++) {
          pt = body2[i]
          if (dir_u && (pt.x == point_u.x) && (pt.y == point_u.y)) {
              if (body2[body2.indexOf(pt) - 1].x > pt.x)
                  trap_right = true;
              else
                  trap_left = true;
          } else if (dir_d && (pt.x == point_d.x) && (pt.y == point_d.y)) {
              if (body2[body2.indexOf(pt) - 1].x < pt.x)
                  trap_right = true;
              else
                  trap_left = true;
          } else if (dir_r && (pt.x == point_r.x) && (pt.y == point_r.y)) {
              if (body2[body2.indexOf(pt) - 1].y > pt.y)
                  trap_right = true;
              else
                  trap_left = true;
          } else if (dir_l && (pt.x == point_l.x) && (pt.y == point_l.y)) {
              if (body2[body2.indexOf(pt) - 1].y < pt.y)
                  trap_right = true;
              else
                  trap_left = true;
          }
  }

  let point_ul = new Point(head2.x - 1, head2.y - 1);
  let point_ur = new Point(head2.x + 1, head2.y - 1);
  let point_uu = new Point(head.x, head.y - 2);
  let point_ll = new Point(head.x - 2, head.y);
  let point_rr = new Point(head.x + 2, head.y);
  let point_dd = new Point(head.x, head.y + 2);
  let point_dr = new Point(head.x + 1, head.y + 1);
  let point_dl = new Point(head.x - 1, head.y + 1);

  let point_of_no_return = false;
  if  ((dir_u && is_collision(point_uu) && is_collision(point_ul) && is_collision(point_ur)) ||
      (dir_l && is_collision(point_ll) && is_collision(point_ul) && is_collision(point_dl)) ||
      (dir_r && is_collision(point_rr) && is_collision(point_dr) && is_collision(point_ur)) ||
      (dir_d && is_collision(point_dd) && is_collision(point_dl) && is_collision(point_dr)))
      point_of_no_return = true;

      state = [
      //Danger straight
      (dir_r && is_collision(point_r)) ||
      (dir_l && is_collision(point_l)) ||
      (dir_u && is_collision(point_u)) ||
      (dir_d && is_collision(point_d)),

      //Danger right
      (dir_u && is_collision(point_r)) ||
      (dir_d && is_collision(point_l)) ||
      (dir_l && is_collision(point_u)) ||
      (dir_r && is_collision(point_d)),

      //Danger left
      (dir_d && is_collision(point_r)) ||
      (dir_u && is_collision(point_l)) ||
      (dir_r && is_collision(point_u)) ||
      (dir_l && is_collision(point_d)),

      //Food location straight
      (dir_l && apple2.x < head2.x) ||
      (dir_r && apple2.x > head2.x) ||
      (dir_u && apple2.y < head2.y) ||
      (dir_d && apple2.y > head2.y) ,

      //Food location right
      (dir_l && apple2.y < head2.y) ||
      (dir_r && apple2.y > head2.y) ||
      (dir_u && apple2.x > head2.x) ||
      (dir_d && apple2.x < head2.x) ,

      //Food location left
      (dir_l && apple2.y > head2.y) ||
      (dir_r && apple2.y < head2.y) ||
      (dir_u && apple2.x < head2.x) ||
      (dir_d && apple2.x > head2.x),

      //tail above head
      (dir_r && tail_right_of_head) ||
      (dir_l && tail_left_of_head) ||
      (dir_u && tail_above_head) ||
      (dir_d && tail_below_head),

      //tail right of head
      (dir_u && tail_right_of_head) ||
      (dir_d && tail_left_of_head) ||
      (dir_l && tail_above_head) ||
      (dir_r && tail_below_head),

      //tail left of head
      (dir_d && tail_right_of_head) ||
      (dir_u && tail_left_of_head) ||
      (dir_r && tail_above_head) ||
      (dir_l && tail_below_head),

      //trap detection
      point_of_no_return,
      trap_right,
      trap_left
    ];

    for (var i = 0; i < state.length; i++) {
      if (state[i] == true)
        state[i] = 1
      if (state[i] == false)
        state[i] = 0
    }
    return state;
}

function is_collision(pt) {
  //hits boundary
  if ((pt.x < 0) || (pt.x >= numTiles) || (pt.y < 0) || (pt.y >= numTilesVertical))
    return true;

  //hits itself
  for (part of body2) {
    if ((part.x == pt.x) && (part.y == pt.y))
      return true;
  }
  return false;
}

async function getMove() {
  state = getState();
  ////console.log(new Float32Array(state))
  try {
    const input = new onnx.Tensor(new Float32Array(state),"float32",[1,12]);
    ////console.log(input)
    const outputMap = await sess.run([input]);
    const outputTensor = outputMap.values().next().value;
    const output = outputTensor.data.indexOf(Math.max(...outputTensor.data));;
    ////console.log(output)
    return output;
  } catch {
    return 0; //move straight if it fails
  }
}

async function move() {
  let dir = 0; //0:up,1:right,2:down,3:left
  switch(xVelocity2) {
    case 1: dir = 1; break;
    case -1: dir = 3; break;
    default:
    switch(yVelocity2) {
      case 1: dir = 2; break;
      case -1: dir = 0; break;
      default: break;
    }; break;
  }
  result = await getMove();
  switch (result) {
    case 1:
    switch(dir) {
      case 0: xVelocity2 = 1; yVelocity2 = 0; break;
      case 1: xVelocity2 = 0; yVelocity2 = 1; break;
      case 2: xVelocity2 = -1; yVelocity2 = 0; break;
      case 3: xVelocity2 = 0; yVelocity2 = -1; break;
    }; break;
    case 2:
    switch(dir) {
      case 0: xVelocity2 = -1; yVelocity2 = 0; break;
      case 1: xVelocity2 = 0; yVelocity2 = -1; break;
      case 2: xVelocity2 = 1; yVelocity2 = 0; break;
      case 3: xVelocity2 = 0; yVelocity2 = 1; break;
    }; break;
    default: break;
  }
}

async function drawGame2() {
  await move();
  ////console.log(xVelocity2,yVelocity2);

  head2.x += xVelocity2;
  head2.y += yVelocity2;

  if (stop2 || isGameOver2()) {
    return;
  }

  //clear canvas
  ctx2.clearRect(0,0, canvas.width, canvas.height);
  ctx2.fillStyle = "black";
  ctx2.fillRect(0, 0, canvas.width, canvas.height);

  drawApple2();
  drawSnake2();

  displayScore2();

  timer2 = setTimeout(drawGame2, 1000 / speed2);
}

function isGameOver2() {
  let gameOver = false;

  if (yVelocity2 === 0 && xVelocity2 === 0) {
    return false;
  }

  //wall collision
  if ((head2.x < 0) || (head2.x >= numTiles) || (head2.y < 0) || (head2.y >= numTilesVertical)) {
    gameOver = true;
    //console.log(head2.x < 0, (head2.x >= numTiles), (head2.y < 0), (head2.y >= numTilesVertical));
  }

  for (let i = 0; i < body2.length; i++) {
    let part = body2[i];
    if (part.x === head2.x && part.y === head2.y) {
      gameOver = true;
      //console.log("hit itself");
      break;
    }
  }

  if (gameOver) {
    //console.log("Game over (AI). Score: " + score2, xVelocity2,yVelocity2);
    start2();
  }

  return gameOver;
}

function displayScore2() {
  ctx2.fillStyle = "white";
  ctx2.font = "10px Verdana";
  ctx2.fillText("Score " + score2, canvas2.width - 50, 10);
  if (score2 > record2) {
    record2 = score2;
    highscore2.textContent = "AI's Highscore: " + record2;
  }
}

function drawSnake2() {
  for (point of body2) {
    ctx2.drawImage(block,point.x * tileSize, point.y * tileSize, tileSize, tileSize);
  }

  body2.push(new Point(head2.x, head2.y)); //add to snake to appear as if it moves
  while (body2.length > tailLength2) {
    body2.shift(); //remove excess points from snake to establish the illusion of movement
  }

  ctx2.drawImage(block,head2.x * tileSize, head2.y * tileSize, tileSize, tileSize);
  // ctx2.fillStyle = "red";
  // ctx2.fillRect(head2.x * tileSize, head2.y * tileSize, tileSize, tileSize);
}

function drawApple2() {
  if (apple2.x === head2.x && apple2.y == head2.y) {
    while (true) {
      apple2.x = random(numTiles);
      apple2.y = random(numTilesVertical);
      for (part of body2) {
        if (part.x == apple2.x && part.y == apple2.y)
          continue;
      }
      break;
    }
    tailLength2++;
    score2++;
  }

  ctx2.drawImage(appleImg,apple2.x * tileSize, apple2.y * tileSize, tileSize, tileSize);
}

//start2();
