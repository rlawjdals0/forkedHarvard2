//inspired by https://github.com/CodingWith-Adam/snake

const canvas = document.getElementById("snake-human");
const ctx = canvas.getContext("2d");
const highscore = document.getElementById("score");
const button = document.getElementById("start-button");

ctx.fillRect(0,0,canvas.width,canvas.height);

let block = document.createElement("img");
block.src = "static/images/whiteblock.png"; //TODO: cite https://chezjau.studio/2d-ground-blocks/
let appleImg = document.createElement("img");
appleImg.src = "static/images/apple.png";

class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
}

let stop = false;

let speed = 20;

let numTiles = 20;
let numTilesVertical = parseInt(numTiles * canvas.height/canvas.width);
let tileSize = canvas.width / numTiles;

let head = new Point(random(numTiles),random(numTilesVertical - 1));

let body = [];
let tailLength = 2;

let apple = new Point(random(numTiles),random(numTilesVertical));
while (apple.x != head.x && apple.y != head.y) {
  apple = new Point(random(numTiles),random(numTilesVertical));
}

let xVelocity = 0;
let yVelocity = 0;

let score = 0;
let record = 0;

function start() {
  if (button.textContent == "Start") {
    stop = false;
    head = new Point(random(numTiles),random(numTilesVertical - 1));

    body = [];
    tailLength = 2;

    apple = new Point(random(numTiles),random(numTilesVertical));
    while (apple.x != head.x && apple.y != head.y) {
      apple = new Point(random(numTiles),random(numTilesVertical));
    }

    xVelocity = 0;
    yVelocity = 0;

    score = 0;
    drawGame();
    button.textContent = "Stop";
  } else {
    stop = true;
    button.textContent = "Start";
  }
}

function random(n) {
  return Math.floor(Math.random() * n);
}

function drawGame() {
  head.x += xVelocity;
  head.y += yVelocity;
  keyPressed = false;

  if (stop || isGameOver()) {
    return;
  }

  //clear canvas
  ctx.clearRect(0,0, canvas.width, canvas.height);
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  drawApple();
  drawSnake();

  displayScore();

  setTimeout(drawGame, 1000 / speed);
}

function isGameOver() {
  let gameOver = false;

  if (yVelocity === 0 && xVelocity === 0) {
    return false;
  }

  //wall collision
  if ((head.x < 0) || (head.x >= numTiles) || (head.y < 0) || (head.y >= numTilesVertical)) {
    gameOver = true;
  }

  for (let i = 0; i < body.length; i++) {
    let part = body[i];
    if (part.x === head.x && part.y === head.y) {
      gameOver = true;
      break;
    }
  }

  if (gameOver) {
    start();
    //console.log("Game over. Score: " + score);
  }

  return gameOver;
}

function displayScore() {
  ctx.fillStyle = "white";
  ctx.font = "10px Verdana";
  ctx.fillText("Score " + score, canvas.width - 50, 10);
  if (score > record) {
    record = score;
    highscore.textContent = "Your Highscore: " + record;
  }
}

function drawSnake() {
  for (point of body) {
    ctx.drawImage(block,point.x * tileSize, point.y * tileSize, tileSize, tileSize);
  }

  body.push(new Point(head.x, head.y)); //add to snake to appear as if it moves
  while (body.length > tailLength) {
    body.shift(); //remove excess points from snake to establish the illusion of movement
  }

  ctx.drawImage(block,head.x * tileSize, head.y * tileSize, tileSize, tileSize);
}

function drawApple() {
  if (apple.x === head.x && apple.y == head.y) {
    while (true) {
      apple.x = random(numTiles);
      apple.y = random(numTilesVertical);
      for (part of body) {
        if (part.x == apple.x && part.y == apple.y)
          continue;
      }
      break;
    }
    tailLength++;
    score++;
  }

  ctx.drawImage(appleImg,apple.x * tileSize, apple.y * tileSize, tileSize, tileSize);
}

document.body.addEventListener("keydown", keyDown);
let keyPressed = false;
function keyDown(event) {
  switch(event.keyCode){
      case 37: case 39: case 38:  case 40:
      case 32: event.preventDefault(); break; //prevent arrow keys and space from scrolling the page
      default: break;
  }

  if (event.keyCode == 38 || event.keyCode == 87) { //up
    if (yVelocity == 1 || keyPressed) return;
    yVelocity = -1;
    xVelocity = 0;
    keyPressed = true;
  }

  if (event.keyCode == 40 || event.keyCode == 83) { //down
    if (yVelocity == -1 || keyPressed) return;
    yVelocity = 1;
    xVelocity = 0;
    keyPressed = true;
  }

  if (event.keyCode == 37 || event.keyCode == 65) { //left
    if (xVelocity == 1 || keyPressed) return;
    yVelocity = 0;
    xVelocity = -1;
    keyPressed = true;
  }

  if (event.keyCode == 39 || event.keyCode == 68) { //right
    if (xVelocity == -1 || keyPressed) return;
    yVelocity = 0;
    xVelocity = 1;
    keyPressed = true;
  }
}
