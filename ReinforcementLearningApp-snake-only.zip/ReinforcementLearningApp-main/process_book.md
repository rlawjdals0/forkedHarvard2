CSCI S14A - Building Interactive Web Applications for Data Analysis
​
# AI Plays vs. You
​
## Project Plan
​
**Meeting Times**: Sunday at 5pm EST (1-2 hours)
​

**Zoom Link**: https://zoom.us/j/3335128102?pwd=djBqTnpzWG9IV09uNlVVTitqM096dz09
​

**Github Repo**: https://github.com/Harvard-DCE-BIWADA/ReinforcementLearningApp
​

**Website Design Template**: https://html5up.net/hyperspace
​

**Website Location**: https://floating-lowlands-28703.herokuapp.com/
 
​
### Team Members
​
Emil Schaumburg - emil.schaumburg@gmail.com

James Kim - 

Nifesimi - 
​
# Milestone 1 Tasks
​
Emil
1. Github repository **COMPLETE**
​

James

1. 
​
All:
1. Choose games to work on and start coding training processes **COMPLETE**
2. Process book and project plan **COMPLETE**
​
# Milestone 2 Tasks
​
Emil
​
1. Train snake algorithm in python **COMPLETE**
2. Improve algorithm by changing parameters **COMPLETE**
3. Create basic app structure/layout **COMPLETE**
4. Choose and apply template to the project **COMPLETE**
5. Deploy app to heroku **COMPLETE**
6. Fix process book and project plan **COMPLETE**
​

Basic overview of what the snake page will look like:
![Untitled drawing](https://user-images.githubusercontent.com/86253731/125211202-6abb4280-e26a-11eb-94a4-25618879804f.jpg)


James
​

1.
​
​
​

# Milestone 3 Tasks
​
Emil
​
1. Import the model using javascript **COMPLETE**
2. Allow the user to play snake **COMPLETE**
3. Make the AI play snake **COMPLETE**
4. Fix the UI of the "snake.html" page **COMPLETE**
5. Create slides for the presentation **IN PROGRESS**
6. Provide visuals of the training **IN PROGRESS**
​

# References & Citations
​
https://github.com/python-engineer/snake-ai-pytorch
