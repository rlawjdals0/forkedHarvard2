//inspired by https://github.com/CodingWith-Adam/snake

const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

let block = document.createElement("img");
block.src = "whiteblock.png"; //TODO: cite https://chezjau.studio/2d-ground-blocks/
let appleImg = document.createElement("img");
appleImg.src = "apple.png";

class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
}

let speed = 10;

let numTiles = 20;
let numTilesVertical = parseInt(numTiles * canvas.height/canvas.width);
let tileSize = canvas.width / numTiles;

let head = new Point(random(numTiles),random(numTilesVertical));

const body = [];
let tailLength = 2;

let apple = new Point(random(numTiles),random(numTilesVertical));
while (apple.x != head.x && apple.y != head.y) {
  apple = new Point(random(numTiles),random(numTilesVertical));
}

let xVelocity = 0;
let yVelocity = 0;

let score = 0;

function random(n) {
  return Math.floor(Math.random() * n);
}

function drawGame() {
  head.x += xVelocity;
  head.y += yVelocity;

  if (isGameOver()) {
    return;
  }

  //clear canvas
  ctx.clearRect(0,0, canvas.width, canvas.height);
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  drawApple();
  drawSnake();

  displayScore();

  setTimeout(drawGame, 1000 / speed);
}

function isGameOver() {
  let gameOver = false;

  if (yVelocity === 0 && xVelocity === 0) {
    return false;
  }

  //wall collision
  if ((head.x < 0) || (head.x >= numTiles) || (head.y < 0) || (head.y >= numTilesVertical)) {
    gameOver = true;
  }

  for (let i = 0; i < body.length; i++) {
    let part = body[i];
    if (part.x === head.x && part.y === head.y) {
      gameOver = true;
      break;
    }
  }

  if (gameOver) {
    console.log("Game over. Score: " + score);
  }

  return gameOver;
}

function displayScore() {
  ctx.fillStyle = "white";
  ctx.font = "10px Verdana";
  ctx.fillText("Score " + score, canvas.width - 50, 10);
}

function drawSnake() {
  for (point of body) {
    ctx.drawImage(block,point.x * tileSize, point.y * tileSize, tileSize, tileSize);
  }

  body.push(new Point(head.x, head.y)); //add to snake to appear as if it moves
  while (body.length > tailLength) {
    body.shift(); //remove excess points from snake to establish the illusion of movement
  }

  ctx.drawImage(block,head.x * tileSize, head.y * tileSize, tileSize, tileSize);
}

function drawApple() {
  if (apple.x === head.x && apple.y == head.y) {
    apple.x = random(numTiles);
    apple.y = random(numTilesVertical);
    tailLength++;
    score++;
  }

  ctx.drawImage(appleImg,apple.x * tileSize, apple.y * tileSize, tileSize, tileSize);
}

document.body.addEventListener("keydown", keyDown);

function keyDown(event) {

  if (event.keyCode == 38 || event.keyCode == 87) {
    if (yVelocity == 1) return;
    yVelocity = -1;
    xVelocity = 0;
  }

  if (event.keyCode == 40 || event.keyCode == 83) {
    if (yVelocity == -1) return;
    yVelocity = 1;
    xVelocity = 0;
  }

  if (event.keyCode == 37 || event.keyCode == 65) {
    if (xVelocity == 1) return;
    yVelocity = 0;
    xVelocity = -1;
  }

  if (event.keyCode == 39 || event.keyCode == 68) {
    if (xVelocity == -1) return;
    yVelocity = 0;
    xVelocity = 1;
  }
}

drawGame();
